package sysc3033.group9.elevatorproject.constants;

/**
 * FilePath string constant
 * 
 * @author Julian Mendoza
 * 
 */
public class FilePath {

	public static final String EVENT_FILE = "/testfolder/eventFile.txt";

}
